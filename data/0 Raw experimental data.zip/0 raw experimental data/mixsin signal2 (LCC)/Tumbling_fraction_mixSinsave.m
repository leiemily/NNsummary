load('tf_mixSin.mat');
%% 1
adaptation00 = zeros(size(TF1{1,3}));
adaptation01 = zeros(size(TF1{1,4}));
for ii = 1:length(TF1)
    adaptation00 = adaptation00+TF1{ii,3};
    adaptation01 = adaptation01+TF1{ii,4};
end
time00 = TF1{1,1};
time01 = TF1{1,2};
adaptation00 = adaptation00/length(TF1);
adaptation01 = adaptation01/length(TF1);

%% 2
adaptation10 = zeros(size(TF2{1,3}));
adaptation11 = zeros(size(TF2{1,4}));
for ii = 1:length(TF2)
    adaptation10 = adaptation10+TF2{ii,3};
    adaptation11 = adaptation11+TF2{ii,4};
end
time10 = TF2{1,1};
time11 = TF2{1,2};
adaptation10 = adaptation10/length(TF2);
adaptation11 = adaptation11/length(TF2);

%% 3
adaptation20 = zeros(size(TF3{1,3}));
adaptation21 = zeros(size(TF3{1,4}));
for ii = 1:length(TF3)
    adaptation20 = adaptation20+TF3{ii,3};
    adaptation21 = adaptation21+TF3{ii,4};
end
time20 = TF3{1,1};
time21 = TF3{1,2};
adaptation20 = adaptation20/length(TF3);
adaptation21 = adaptation21/length(TF3);

%% 4
adaptation30 = zeros(size(TF4{1,3}));
adaptation31 = zeros(size(TF4{1,4}));
for ii = 1:length(TF4)
    adaptation30 = adaptation30+TF4{ii,3};
    adaptation31 = adaptation31+TF4{ii,4};
end
time30 = TF4{1,1};
time31 = TF4{1,2};
adaptation30 = adaptation30/length(TF4);
adaptation31 = adaptation31/length(TF4);

%% 5
adaptation40 = zeros(size(TF5{1,3}));
adaptation41 = zeros(size(TF5{1,4}));
for ii = 1:length(TF5)
    adaptation40 = adaptation40+TF5{ii,3};
    adaptation41 = adaptation41+TF5{ii,4};
end
time40 = TF5{1,1};
time41 = TF5{1,2};
adaptation40 = adaptation40/length(TF5);
adaptation41 = adaptation41/length(TF5);

%% 6
adaptation50 = zeros(size(TF6{1,3}));
adaptation51 = zeros(size(TF6{1,4}));
for ii = 1:length(TF6)
    adaptation50 = adaptation50+TF6{ii,3};
    adaptation51 = adaptation51+TF6{ii,4};
end
time50 = TF6{1,1};
time51 = TF6{1,2};
adaptation50 = adaptation50/length(TF6);
adaptation51 = adaptation51/length(TF6);

%% 7
adaptation60 = zeros(size(TF7{1,3}));
adaptation61 = zeros(size(TF7{1,4}));
for ii = 1:length(TF7)
    adaptation60 = adaptation60+TF7{ii,3};
    adaptation61 = adaptation61+TF7{ii,4};
end
time60 = TF7{1,1};
time61 = TF7{1,2};
adaptation60 = adaptation60/length(TF7);
adaptation61 = adaptation61/length(TF7);

%% 8
adaptation70 = zeros(size(TF8{1,3}));
adaptation71 = zeros(size(TF8{1,4}));
for ii = 1:length(TF8)
    adaptation70 = adaptation70+TF8{ii,3};
    adaptation71 = adaptation71+TF8{ii,4};
end
time70 = TF8{1,1};
time71 = TF8{1,2};
adaptation70 = adaptation70/length(TF8);
adaptation71 = adaptation71/length(TF8);

t = time01;
Fnoise_save = [adaptation01';adaptation11';adaptation21';adaptation31';...
    adaptation41';adaptation51';adaptation61';adaptation71'];
S_save = [I1.II';I2.II';I3.II';I4.II';I5.II';I6.II';I7.II';I8.II'];
S_save = S_save(:,9:10:end);

Fnoise_save = [Fnoise_save([3,7,8,6],:);Fnoise_save([2,1,4,5],:)];
S_save = [S_save([3,7,8,6],:);S_save([2,1,4,5],:)];

for i =1:8
    figure(2)
    subplot(2,4,i)
    plot(t,Fnoise_save(i,:));
    yyaxis right;
    plot(t,S_save(i,:),'--');
end

save('tumbling_fraction_mixsinall.mat','t','S_save','Fnoise_save');