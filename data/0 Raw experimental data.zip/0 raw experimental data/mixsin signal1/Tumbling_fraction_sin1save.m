clear;
load('tf_Sin1.mat');
adaptation10 = zeros(size(TF1{1,3}));
adaptation11 = zeros(size(TF1{1,4}));
for ii = 1:length(TF1)
    adaptation10 = adaptation10+TF1{ii,3};
    adaptation11 = adaptation11+TF1{ii,4};
end
time10 = TF1{1,1};
time11 = TF1{1,2};
adaptation10 = adaptation10/length(TF1);
adaptation11 = adaptation11/length(TF1);
subplot(3,1,1);
plot(time10,adaptation10);
yyaxis right;
plot(time10,I1.II);

adaptation20 = zeros(size(TF2{1,3}));
adaptation21 = zeros(size(TF2{1,4}));
for ii = 1:length(TF2)
    adaptation20 = adaptation20+TF2{ii,3};
    adaptation21 = adaptation21+TF2{ii,4};
end
time20 = TF2{1,1};
time21 = TF2{1,2};
adaptation20 = adaptation20/length(TF2);
adaptation21 = adaptation21/length(TF2);
subplot(3,1,2);
plot(time20,adaptation20);
yyaxis right;
plot(time20,I2.II);

adaptation30 = zeros(size(TF3{1,3}));
adaptation31 = zeros(size(TF3{1,4}));
for ii = 1:length(TF3)
    adaptation30 = adaptation30+TF3{ii,3};
    adaptation31 = adaptation31+TF3{ii,4};
end
time30 = TF3{1,1};
time31 = TF3{1,2};
adaptation30 = adaptation30/length(TF3);
adaptation31 = adaptation31/length(TF3);
subplot(3,1,3);
plot(time30,adaptation30);
yyaxis right;
plot(time30,I3.II);

t = time21;
S_save = [I1.II,I2.II,I3.II]';
S_save = S_save(:,9:10:end);
Fnoise_save = [adaptation11,adaptation21,adaptation31]';

save('tumbling_fraction_sin1all.mat','t','S_save','Fnoise_save');