load('tf_Step1.mat');
%% 1
adaptation10 = zeros(size(TF1{1,3}));
adaptation11 = zeros(size(TF1{1,4}));
for ii = 1:length(TF1)
    adaptation10 = adaptation10+TF1{ii,3};
    adaptation11 = adaptation11+TF1{ii,4};
end
adaptation10 = adaptation10/length(TF1);
adaptation11 = adaptation11/length(TF1);
S1 = I1.intense;
Frac1 = adaptation11;


%% 2
adaptation20 = zeros(size(TF2{1,3}));
adaptation21 = zeros(size(TF2{1,4}));
for ii = 1:length(TF2)
    adaptation20 = adaptation20+TF2{ii,3};
    adaptation21 = adaptation21+TF2{ii,4};
end
adaptation20 = adaptation20/length(TF2);
adaptation21 = adaptation21/length(TF2);
S2 = I2.intense;
Frac2 = adaptation21;
%% 3
adaptation30 = zeros(size(TF3{1,3}));
adaptation31 = zeros(size(TF3{1,4}));
for ii = 1:length(TF3)
    adaptation30 = adaptation30+TF3{ii,3};
    adaptation31 = adaptation31+TF3{ii,4};
end
adaptation30 = adaptation30/length(TF3);
adaptation31 = adaptation31/length(TF3);
S3 = I3.intense;
Frac3 = adaptation31;

%% 4
adaptation40 = zeros(size(TF4{1,3}));
adaptation41 = zeros(size(TF4{1,4}));
for ii = 1:length(TF4)
    adaptation40 = adaptation40+TF4{ii,3};
    adaptation41 = adaptation41+TF4{ii,4};
end
adaptation40 = adaptation40/length(TF4);
adaptation41 = adaptation41/length(TF4);
S4 = I4.intense;
Frac4 = adaptation41;

%% 5
adaptation50 = zeros(size(TF5{1,3}));
adaptation51 = zeros(size(TF5{1,4}));
for ii = 1:length(TF5)
    adaptation50 = adaptation50+TF5{ii,3};
    adaptation51 = adaptation51+TF5{ii,4};
end
adaptation50 = adaptation50/length(TF5);
adaptation51 = adaptation51/length(TF5);
S5 = I5.intense;
Frac5 = adaptation51;

%% 6
adaptation60 = zeros(size(TF6{1,3}));
adaptation61 = zeros(size(TF6{1,4}));
for ii = 1:length(TF6)
    adaptation60 = adaptation60+TF6{ii,3};
    adaptation61 = adaptation61+TF6{ii,4};
end
adaptation60 = adaptation60/length(TF6);
adaptation61 = adaptation61/length(TF6);
S6 = I6.intense;
Frac6 = adaptation61;

%% 7
adaptation70 = zeros(size(TF7{1,3}));
adaptation71 = zeros(size(TF7{1,4}));
for ii = 1:length(TF7)
    adaptation70 = adaptation70+TF7{ii,3};
    adaptation71 = adaptation71+TF7{ii,4};
end
adaptation70 = adaptation70/length(TF7);
adaptation71 = adaptation71/length(TF7);
S7 = I7.intense;
Frac7 = adaptation71;

%% 8
adaptation80 = zeros(size(TF8{1,3}));
adaptation81 = zeros(size(TF8{1,4}));
for ii = 1:length(TF8)
    adaptation80 = adaptation80+TF8{ii,3};
    adaptation81 = adaptation81+TF8{ii,4};
end
adaptation80 = adaptation80/length(TF8);
adaptation81 = adaptation81/length(TF8);
S8 = I8.intense;
Frac8 = adaptation81;

%% 9
adaptation90 = zeros(size(TF9{1,3}));
adaptation91 = zeros(size(TF9{1,4}));
for ii = 1:length(TF9)
    adaptation90 = adaptation90+TF9{ii,3};
    adaptation91 = adaptation91+TF9{ii,4};
end
adaptation90 = adaptation90/length(TF9);
adaptation91 = adaptation91/length(TF9);
S9 = I9.intense;
Frac9 = adaptation91;

%% 10
adaptation100 = zeros(size(TF10{1,3}));
adaptation101 = zeros(size(TF10{1,4}));
for ii = 1:length(TF10)
    adaptation100 = adaptation100+TF10{ii,3};
    adaptation101 = adaptation101+TF10{ii,4};
end
adaptation100 = adaptation100/length(TF10);
adaptation101 = adaptation101/length(TF10);
S10 = I10.intense;
Frac10 = adaptation101;

%% save
S_save = [S1;S2;S3;S4;S5;S6;S7;S8;S9;S10];
Fnoise_save = [Frac1,Frac2,Frac3,Frac4,Frac5,Frac6,Frac7,Frac8,Frac9,Frac10]';
%% figures
t = TF1{1,2};
for i = 1:10
    subplot(5,2,i);
    plot(t,Fnoise_save(i,:));
    yyaxis right;
    plot(t,S_save(i,:));
end

% save('tumbling_fraction_step1all.mat','t','S_save','Fnoise_save');