%% original plot
load('tf_Trapzoid.mat');

%% 1
adaptation00 = zeros(size(TF1{1,3}));
adaptation01 = zeros(size(TF1{1,4}));
for ii = 1:length(TF1)
    adaptation00 = adaptation00+TF1{ii,3};
    adaptation01 = adaptation01+TF1{ii,4};
end
time00 = TF1{1,1};
time01 = TF1{1,2};
adaptation00 = adaptation00/length(TF1);
adaptation01 = adaptation01/length(TF1);

%% 2
adaptation10 = zeros(size(TF2{1,3}));
adaptation11 = zeros(size(TF2{1,4}));
for ii = 1:length(TF2)
    adaptation10 = adaptation10+TF2{ii,3};
    adaptation11 = adaptation11+TF2{ii,4};
end
time10 = TF2{1,1};
time11 = TF2{1,2};
adaptation10 = adaptation10/length(TF2);
adaptation11 = adaptation11/length(TF2);

%% 3
adaptation20 = zeros(size(TF3{1,3}));
adaptation21 = zeros(size(TF3{1,4}));
for ii = 1:length(TF3)
    adaptation20 = adaptation20+TF3{ii,3};
    adaptation21 = adaptation21+TF3{ii,4};
end
time20 = TF3{1,1};
time21 = TF3{1,2};
adaptation20 = adaptation20/length(TF3);
adaptation21 = adaptation21/length(TF3);

%% save
t = time01;
Snoise_save = [I1.intense,I2.intense,I3.intense]';
Snoise_save = Snoise_save(:,9:10:end);
Fnoise_save = [adaptation01,adaptation11,adaptation21]';
S_save = [];
for i =1:3
%     s = csaps(t,S_save(i,:),1e-5,t);
%     s = interp1(t,S_save(i,:),t);
    s = Snoise_save(i,:);
    s_diff = diff(s);
    s_n1 = find(s_diff)+1;
    s_n2 = find(s_diff);
    
    s_n2 = [0,s_n2,length(s)];
    s_ndiff = diff(s_n2);
    s_nn = [];
    for j = 1:length(s_ndiff)
        if s_ndiff(j)>8
             s_nn = [s_nn,s_n2(j+1)];
        else if s_ndiff(j+1)>8
             s_nn = [s_nn,  s_n1(j)]; 
            end
        end
    end
    s_nn = [1,s_nn];
    ss = interp1(t(s_nn),Snoise_save(i,s_nn),t);
    S_save = [S_save;ss];
    figure(2)
    subplot(3,1,i)
    plot(t,Fnoise_save(i,:));
    yyaxis right;
    plot(t,s,'--');hold on
    plot(t,ss,'-');
end

save('tumbling_fraction_trapzall.mat','t','S_save','Fnoise_save');